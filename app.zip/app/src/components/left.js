/**
 *  @Author    左边模块
 *  @DateTime  2017-02-22
 *  @describe  [公司公告]
 */

import React from 'react'
import { Component } from 'react'

class Left  extends Component {
  render(){
    return <div className='left'></div>
  }
}

export { Left }
